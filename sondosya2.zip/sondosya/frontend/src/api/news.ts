export interface Tag {
    id: number;
    name: string;
}

export interface News {
    id: number;
    title: string;
    clean_title: string | null;
    content: string;
    url: string;
    image_url: string | null;
    source: string;
    published_at: string;
    summary_bullets: string[] | null;
    sentiment: string | null;
    tags: Tag[];
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export async function fetchNews(): Promise<News[]> {
    const response = await fetch(`${API_BASE_URL}/news`, {
        cache: "no-store",
    });
    if (!response.ok) {
        throw new Error("Failed to fetch news");
    }
    return response.json();
}

export async function fetchHealth(): Promise<{ status: string }> {
    const response = await fetch(`${API_BASE_URL}/health`);
    if (!response.ok) {
        throw new Error("Backend is unreachable");
    }
    return response.json();
}
