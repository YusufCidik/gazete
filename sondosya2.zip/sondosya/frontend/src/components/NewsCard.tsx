import React from 'react';
import { News } from '../api/news';

interface NewsCardProps {
    news: News;
}

export const NewsCard: React.FC<NewsCardProps> = ({ news }) => {
    const sentimentColor =
        news.sentiment === 'Pozitif' ? 'text-green-600' :
            news.sentiment === 'Negatif' ? 'text-red-600' : 'text-gray-600';

    return (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-2xl transition-shadow duration-300">
            {news.image_url && (
                <img src={news.image_url} alt={news.title} className="w-full h-48 object-cover" />
            )}
            <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                    <span className="text-xs font-semibold uppercase tracking-wider text-blue-600">
                        {news.source}
                    </span>
                    <span className={`text-xs font-bold px-2 py-1 rounded ${sentimentColor} bg-opacity-10 bg-current`}>
                        {news.sentiment}
                    </span>
                </div>

                <h2 className="text-xl font-bold text-gray-900 mb-2 leading-tight">
                    {news.clean_title || news.title}
                </h2>

                {news.summary_bullets && (
                    <ul className="list-disc list-inside text-sm text-gray-600 mb-4 space-y-1">
                        {news.summary_bullets.map((bullet, idx) => (
                            <li key={idx}>{bullet}</li>
                        ))}
                    </ul>
                )}

                <div className="flex flex-wrap gap-2 mb-4">
                    {news.tags.map(tag => (
                        <span key={tag.id} className="text-xs bg-gray-100 text-gray-500 px-2 py-1 rounded-full">
                            #{tag.name}
                        </span>
                    ))}
                </div>

                <a
                    href={news.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block text-blue-600 font-semibold text-sm hover:underline"
                >
                    Haberi Oku &rarr;
                </a>
            </div>
        </div>
    );
};
