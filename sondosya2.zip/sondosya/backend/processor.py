import os
import json
from typing import List, Dict, Optional
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel("gemini-2.0-flash")


class AIProcessor:
    @staticmethod
    async def process_content(title: str, content: str) -> Dict:
        """
        Analyzes news title and content using Gemini API in a single call.
        Cleans clickbait titles, summarizes content, and performs sentiment analysis.
        """
        prompt = f"""
Sen profesyonel, objektif ve keskin bir haber editörüsün. 
Görevin, aşağıda verilen ham haberi analiz ederek tıklama tuzağından (clickbait) arındırmak ve kullanıcıya en saf bilgiyi sunmaktır.

HAM VERİLER:
Haber Başlığı: {title}
Haber İçeriği: {content}

TALİMATLAR:
1. Başlık Temizleme: Eğer başlık "Şok gelişme!", "Buna inanamayacaksınız", "Bakın ne oldu?" gibi merak uyandırıcı ama bilgi vermeyen bir yapıdaysa, bunu tamamen sil. Yerine haberin ana fikrini anlatan, ciddi, 3. tekil şahıs dilinde (örn: "X Bakanlığı yeni düzenlemeyi açıkladı") profesyonel bir başlık yaz.
2. Özetleme: Haberin en can alıcı noktalarını seçerek maksimum 3 maddelik (bullet point) bir özet oluştur. Her madde kısa ve öz olmalı.
3. Duygu Analizi: Haberin genel tonunu analiz et ve sadece şu üç değerden birini ata: "Pozitif", "Negatif", "Nötr".

YANIT FORMATI:
Yanıtı SADECE ve SADECE aşağıdaki JSON formatında, kod bloğu olmadan ver:
{{
    "clean_title": "Temizlenmiş Profesyonel Başlık",
    "summary": ["Önemli madde 1", "Önemli madde 2", "Önemli madde 3"],
    "sentiment": "Pozitif/Negatif/Nötr"
}}
"""
        try:
            response = model.generate_content(prompt)
            text = response.text.strip()
            
            # Remove markdown code block if present
            if text.startswith("```"):
                text = text.split("\n", 1)[1]
                text = text.rsplit("```", 1)[0].strip()
            
            # Remove JSON prefix if any (e.g., "json\n{...")
            if text.lower().startswith("json"):
                text = text[4:].strip()
                
            data = json.loads(text)
            return {
                "clean_title": data.get("clean_title", title),
                "summary": data.get("summary", ["Özet çıkarılamadı."]),
                "sentiment": data.get("sentiment", "Nötr")
            }
        except Exception as e:
            print(f"Error in unified processing: {e}")
            return {
                "clean_title": title,
                "summary": ["İşleme hatası oluştu."],
                "sentiment": "Nötr"
            }

    @staticmethod
    async def extract_tags(content: str) -> List[str]:
        """Extracts entities and tags in Turkish (Separate call for better focus)."""
        prompt = (
            f"Bu haberden en önemli 5 anahtar kelimeyi veya kişiyi/kurumu çıkar. "
            f"Yanıtını SADECE JSON formatında ver, başka hiçbir şey yazma. "
            f'Format: {{"etiketler": ["etiket1", "etiket2", ...]}}\n\n'
            f"Haber: '{content}'"
        )
        try:
            response = model.generate_content(prompt)
            text = response.text.strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[1]
                text = text.rsplit("```", 1)[0].strip()
            if text.lower().startswith("json"):
                text = text[4:].strip()
            data = json.loads(text)
            return data.get("etiketler", [])
        except Exception as e:
            print(f"Error extracting tags: {e}")
            return []
