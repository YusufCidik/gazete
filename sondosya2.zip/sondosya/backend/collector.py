import asyncio
import feedparser
from datetime import datetime
from database import AsyncSessionLocal
from models import News, Tag
from processor import AIProcessor
from sqlalchemy.future import select

class Collector:
    def __init__(self):
        self.processor = AIProcessor()
        # Gerçek haber kaynakları
        self.sources = {
            "NTV": "https://www.ntv.com.tr/son-dakika.rss",
            "BBC": "https://feeds.bbci.co.uk/turkce/rss.xml",
            "TRT": "https://www.trthaber.com/manset.rss"
        }

    async def fetch_rss_news(self):
        """Gerçek RSS feedlerinden haberleri çeker."""
        news_items = []
        for source_name, rss_url in self.sources.items():
            try:
                # RSS verisini çek ve parçala
                feed = feedparser.parse(rss_url)
                for entry in feed.entries[:5]: # Her kaynaktan en yeni 5 haber
                    news_items.append({
                        "title": entry.title,
                        "content": entry.get("summary") or entry.get("description") or "",
                        "url": entry.link,
                        "source": source_name,
                        "image_url": entry.get("media_content", [{}])[0].get("url") if entry.get("media_content") else "https://via.placeholder.com/800x600?text=GazeteYapayZeka"
                    })
            except Exception as e:
                print(f"RSS Çekme Hatası ({source_name}): {e}")
        return news_items

    async def process_and_save(self):
        # Mock yerine gerçek haberleri çağırıyoruz
        news_items = await self.fetch_rss_news()
        
        async with AsyncSessionLocal() as session:
            for item in news_items:
                # Haber zaten var mı kontrol et
                stmt = select(News).where(News.url == item["url"])
                result = await session.execute(stmt)
                if result.scalar_one_or_none():
                    continue

                print(f"Processing: {item['title'][:50]}...")
                
                # Gemini ile Profesyonel Analiz
                processed_data = await self.processor.process_content(item["title"], item["content"])
                
                if not processed_data:
                    continue

                new_news = News(
                    title=item["title"],
                    clean_title=processed_data["clean_title"],
                    content=item["content"],
                    url=item["url"],
                    source=item["source"],
                    image_url=item["image_url"],
                    summary_bullets=processed_data["summary"],
                    sentiment=processed_data["sentiment"]
                )

                # Tag çıkarma işlemi (Opsiyonel)
                try:
                    tags_list = await self.processor.extract_tags(item["content"])
                    for tag_name in tags_list:
                        tag_stmt = select(Tag).where(Tag.name == tag_name)
                        tag_result = await session.execute(tag_stmt)
                        tag = tag_result.scalar_one_or_none()
                        if not tag:
                            tag = Tag(name=tag_name)
                        new_news.tags.append(tag)
                except Exception as e:
                    print(f"Tag hatası: {e}")

                session.add(new_news)
            
            await session.commit()
            print("✅ Yeni haberler başarıyla kaydedildi.")

async def run_collector():
    collector = Collector()
    while True:
        print(f"[{datetime.now()}] Collector starting cycle...")
        try:
            await collector.process_and_save()
        except Exception as e:
            print(f"Collector Error: {e}")
        print("Collector finished cycle. Sleeping for 15 minutes...")
        await asyncio.sleep(900)