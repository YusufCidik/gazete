from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.ext.asyncio import AsyncSession
from database import engine, get_db, AsyncSessionLocal
from models import Base
import asyncio
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Gazete Yapay Zeka API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Next.js default port
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    logger.info("Initializing database tables...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    logger.info("Starting background collector...")
    from collector import run_collector
    asyncio.create_task(run_collector())

@app.get("/news")
async def get_news(db: AsyncSession = Depends(get_db)):
    from sqlalchemy.future import select
    from models import News
    from sqlalchemy.orm import selectinload
    
    stmt = select(News).options(selectinload(News.tags)).order_by(News.published_at.desc())
    result = await db.execute(stmt)
    return result.scalars().all()

@app.get("/health")
async def health():
    return {"status": "healthy"}
