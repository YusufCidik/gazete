from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Table, JSON
from sqlalchemy.orm import relationship, declarative_base
from datetime import datetime

Base = declarative_base()

news_tags = Table(
    "news_tags",
    Base.metadata,
    Column("news_id", Integer, ForeignKey("news.id"), primary_key=True),
    Column("tag_id", Integer, ForeignKey("tags.id"), primary_key=True),
)

class News(Base):
    __tablename__ = "news"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    clean_title = Column(String, index=True, nullable=True) # AI Processed factual title
    content = Column(Text)
    url = Column(String, unique=True)
    image_url = Column(String, nullable=True)
    source = Column(String)
    published_at = Column(DateTime, default=datetime.utcnow)
    collected_at = Column(DateTime, default=datetime.utcnow)
    
    # AI Processed fields
    summary_bullets = Column(JSON, nullable=True) # List of 3 bullets
    sentiment = Column(String, nullable=True) # Positive, Negative, Neutral
    
    tags = relationship("Tag", secondary=news_tags, back_populates="news")

class Tag(Base):
    __tablename__ = "tags"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    
    news = relationship("News", secondary=news_tags, back_populates="tags")
