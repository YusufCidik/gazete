import asyncio
from models import Base
from database import engine

async def init():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print('✅ Tablolar basariyla olusturuldu!')

if __name__ == '__main__':
    asyncio.run(init())